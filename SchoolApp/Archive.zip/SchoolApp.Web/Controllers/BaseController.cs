﻿using Microsoft.AspNetCore.Mvc;

namespace SchoolApp.Web.Controllers
{
	public class BaseController : Controller
    {
		
	}
}