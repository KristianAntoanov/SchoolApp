﻿namespace SchoolApp.Web.ViewModels
{
	public class DiaryIndexViewModel
	{
		public int ClassId { get; set; }

		public string ClassName { get; set; } = null!;
	}
}