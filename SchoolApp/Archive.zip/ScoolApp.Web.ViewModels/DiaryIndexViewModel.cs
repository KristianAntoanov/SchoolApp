﻿namespace SchoolApp.Web.ViewModels
{
	public class DiaryIndexViewModel
	{
		public string ClassName { get; set; } = null!;
	}
}