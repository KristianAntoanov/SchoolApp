﻿namespace SchoolApp.Web.ViewModels
{
	public class SubjectsViewModel
	{
		public string SubjectName { get; set; } = null!;
	}
}