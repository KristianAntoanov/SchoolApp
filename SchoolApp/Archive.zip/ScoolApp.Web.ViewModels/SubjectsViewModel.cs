﻿namespace SchoolApp.Web.ViewModels
{
	public class SubjectsViewModel
	{
		public int Id { get; set; }

		public string SubjectName { get; set; } = null!;
	}
}